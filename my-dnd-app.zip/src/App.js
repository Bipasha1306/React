import logo from "./logo.svg";
import "./App.css";
import { Table } from "./Components/Table";

function App() {
  return (
    <div className="App">
      <h2>Welcome To react</h2>
      <Table></Table>
    </div>
  );
}

export default App;
