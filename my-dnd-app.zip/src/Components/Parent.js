import React from "react";

export const Parent = () => {
  const Display = () => {
    <h1>Hello</h1>;
  };

  return (
    <div>
      <Display></Display>
    </div>
  );
};

export const Hello = () => {
  console.log("Something is Happening");
  <h1>heelllo</h1>;
  alert("hellloo");
};
