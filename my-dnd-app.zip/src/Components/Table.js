import React, { useState } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";
import { Hello } from "./Parent";
import FileSaver from "file-saver";
import * as XLSX from "xlsx";

//import Calendar from "react-calendar";
export const Table = () => {
  //  const [value, onChange] = useState(new Date());
  const data = [
    {
      name: "->Max->cat->fish",
      pet: "",
      food: "",
      age: 29,
      lname: "Paul",
      loc: "",
    },
    {
      name: "->Dan->Dog->bone",
      pet: "",
      food: "",
      age: 2,
      lname: "Martha",
      loc: "",
    },
    {
      name: "->Harry->bird->worm",
      pet: "",
      food: "",
      age: 9,
      lname: "Logan",
      loc: "",
    },
    {
      name: "->Harmone->dog->chips",
      pet: "",
      food: "",
      age: 21,
      lname: "Tim",
      loc: "",
    },
  ];

  const col = [
    {
      headerName: "Name",
      field: "name",
      cellClass: "name",
      valueGetter: function (params) {
        return `${params.data.name}`;
      },
    },
    {
      headerName: "Pet",
      field: "pet",
    },
    {
      headerName: "Food",
      field: "food",
    },
    {
      headerName: "LastName",
      field: "lname",
      cellClass: "lname",
      // valueGetter: function (params) {
      //   return `${params.data.name}`;
      // },
    },
    {
      headerName: "Age",
      field: "age",
      cellClass: "age",
      valueGetter: (params) => {
        return `${params.data.age}`;
      },
      // initialPinned: "left",
    },
    {
      headerName: "Location",
      field: "loc",
      cellClass: "loc",
    },
  ];
  // const excelStyles = [
  //   {
  //     id: "detail",
  //     dataType: "Formula",
  //   },
  //   {
  //     id: "name",
  //     dataType: "Formula",
  //   },
  // ];
  const defaultColDef = {
    sortable: true,
    filter: true,
    editable: true,
    //suppressColumnMoveAnimation:true,
  };

  const gridOptions = {
    excelStyles: [
      {
        id: "name",
        dataType: "Formula",
      },
    ],
  };
  const defaultExcelExportParams = {};

  let gridApi;
  const onGridReady = (params) => {
    gridApi = params.api;
  };

  const click = () => {
    const value = gridApi.getDataAsCsv();

    console.log(value);
    const search = '"';
    const replaceWith = "";

    const res = value.replaceAll(search, replaceWith);
    console.log(res);

    var lines = res.split("\n");
    console.log("stage 1---", lines);

    var result = [];
    var a1 = [];

    var headers = lines[0].split(",");
    console.log("stage 2---", headers);
    for (var i = 1; i < lines.length; i++) {
      var obj = {};
      var currentline = lines[i].split(",");
      var first = currentline.slice(0, 1);
      var second = currentline.slice(1);
      second = second.filter((entry) => entry.trim() != "");
      console.log({ first, second });
      console.log("stage 3 currentline---", currentline);

      console.log("first chunk array", first);
      var newLineFirst = first[0].split("->");
      //  var a =first;
      //  console.log(a)
      newLineFirst.shift();

      console.log("stage 4 newLineFirst--", newLineFirst);
      var newLine = newLineFirst.concat(second);
      console.log("stage 5 newLine--", newLine);

      for (var j = 0; j < headers.length; j++) {
        obj[headers[j]] = newLine[j];
      }

      result.push(obj);
    }
    console.log("result", result);
    const csvData = JSON.stringify(result);
    console.log("csvData---", csvData);
    // return xy;
    // return value;

    const fileType =
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";

    const fileExtension = ".xlsx";
    const fileName = "MyFile";

    const exportToCSV = (csvData, fileName) => {
      const ws = XLSX.utils.json_to_sheet(csvData);

      const wb = { Sheets: { data: ws }, SheetNames: ["data"] };

      const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });

      const data = new Blob([excelBuffer], { type: fileType });

      FileSaver.saveAs(data, fileName + fileExtension);
    };
    exportToCSV(result, "file123");
  };

  const onExportClick = () => {
    gridApi.exportDataAsCsv();
  };

  const onTest = () => {
    Hello();
  };

  return (
    <div>
      <button onClick={() => onExportClick()}>export</button>
      <button onClick={() => click()}>Testing</button>
      <div className="ag-theme-alpine" style={{ height: 400, width: 600 }}>
        Ag-grid
        <AgGridReact
          rowData={data}
          columnDefs={col}
          defaultColDef={defaultColDef}
          onGridReady={onGridReady}
          // excelStyles={excelStyles}
          defaultExcelExportParams={defaultExcelExportParams}
          gridOptions={gridOptions}
        ></AgGridReact>
      </div>
    </div>
  );
};
